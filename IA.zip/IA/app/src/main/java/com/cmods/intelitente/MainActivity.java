package com.cmods.intelitente;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.text.TextWatcher;
import android.view.View;
import android.text.Editable;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
	
	private String re = "";
	private String re1 = "";
	private String re2 = "";
	private String re3 = "";
	private String re4 = "";
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private EditText edittext1;
	private Button iniciar_i_a;
	private TextView mebot;
	private RequestNetwork rn;
	private RequestNetwork.RequestListener _rn_request_listener;
	
    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
}

	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		edittext1 = findViewById(R.id.edittext1);
		iniciar_i_a = findViewById(R.id.iniciar_i_a);
		mebot = findViewById(R.id.mebot);
		rn = new RequestNetwork(this);

		edittext1.addTextChangedListener(new TextWatcher() {
				@Override
				public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
					final String _charSeq = _param1.toString();
					iniciar_i_a.setVisibility(View.VISIBLE);
				}
				@Override
				public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				}
				@Override
				public void afterTextChanged(Editable _param1) {

				}
			});

		iniciar_i_a.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					rn.startRequestNetwork(RequestNetworkController.GET, "http://api.brainshop.ai/get?bid=172940&key=6D5JMQz74YSn0YZb&uid=".concat("123456".concat("&msg=".concat(edittext1.getText().toString()))), "", _rn_request_listener);
					edittext1.setText("");
					edittext1.setEnabled(false);
					edittext1.setEnabled(true);
					iniciar_i_a.setVisibility(View.GONE);
				}
			});

		_rn_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _response = _param2;
				re = _response.replace("cnt", "");
				re1 = re.replace("{", "");
				re2 = re1.replace("}", "");
				re3 = re2.replace("\"", "");
				re4 = re3.replace(":", "");
				mebot.setText(re4);
			}

			@Override
			public void onErrorResponse(String _param1, String _param2) {
				//showMessage(_param2);
			}
		};
	}

	private void initializeLogic() {
		iniciar_i_a.setVisibility(View.GONE);
	}


	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
}
